package edu.kosta.kdc.exception;

public class KdcException extends RuntimeException {
	public KdcException() {}
	public KdcException(String msg) {
		super(msg);
	}
}
