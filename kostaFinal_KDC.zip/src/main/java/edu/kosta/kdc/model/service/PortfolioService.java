package edu.kosta.kdc.model.service;

public interface PortfolioService {

}
