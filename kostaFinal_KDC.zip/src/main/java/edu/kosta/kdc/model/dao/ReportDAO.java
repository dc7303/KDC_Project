package edu.kosta.kdc.model.dao;

public interface ReportDAO {

}
